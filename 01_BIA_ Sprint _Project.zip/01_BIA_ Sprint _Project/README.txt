Project Objectives 

As a consultant, the goal for the project objectives is to analyze the vacation rental market in the Manhattan area in New York City. 
The client is interested in investing in several properties but would like to know what kind of properties are worth investing in the area. 

Questions to answer through the analysis 
- Which neighborhoods are most attractive for vacation rentals
- Which size properties (i.e., how many bedrooms) are most popular for vacation rentals
- Calculating occupancy
- What’s the average occupancy for each listing
- Which days of the week have the highest occupancy rates
- Estimate revenue for an investment property
- What attributes are important for a vacation rental

Outcomes/Suggestions 
Focusing on the entire rental units with 1 bath and about 13% occupancy rate properties in Lower East Side, Helles Kitchen, and Harlem would be a good investment in NYC.  