Project Objectives 
As a junior analysis for Zomato, which is a multinational restaurant aggregator and food delivery company, 
using the given dataset, the project aims to analyze the business performance of restaurants and customers. 

Questions to answer through the analysis 
- Who is the main customer segment 
- What are the purchasing behavior 

Outcome/ Suggestions 
- 1st customer segment is the 20s (both male and female), students in graduate or post-graduate, single, and with no stable income.
- 2nd one is 20s (More male customers than female), family size of more than 2, graduate degree holder, and monthly income 25001 to 50000 INR.
- 3rd core pool is the 20s, with family size of more than 2, graduate degree holders, and monthly incomes 10001 to 25000 INR
- The sum of sales and quantity has been declining since 2018, yet the average sales, quantity, and sales per quantity have positive tendencies
- Overall sales have declined since 2018, yet the sales per quantity have improved, meaning one customer spends more than 2019
- Using the restaurant popularity data, Zotoma can conduct a collaborative campaign to boost sales

- Revisit the current digital marketing campaigns to adjust the target audience to align with Zomato’s core customer segment. It will help to use the budget more effectively and expect a sales boost 
- Consider launching a new campaign to work with educational institutions (universities or colleges)  to raise sales
- Partner up with a popular restaurant to increase sales 



